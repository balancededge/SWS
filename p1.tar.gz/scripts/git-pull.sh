git pull
make
./sws